package pj.MontzLibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MontzLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MontzLibraryApplication.class, args);
	}

}
